# Lecture 25 IDE walkthrough

| Slides | File | Topics demonstrated |
|---|---|---|
| 4–7 | Slide04_RecursiveSumProof.java | Base case, progress measure, correctness argument, linear cost |
| 8–10 | Slide08_FibonacciCallTree.java | Repeated work, time, and stack depth |
| 11–14 | Slide12_MemoizedFibonacci.java | Memoization, public wrapper, private helper |
| 15 | Slide15_CompareFibonacciCalls.java | Measured naive versus memoized call counts |
| 16–17 | Slide17_HeadAndTailSum.java | Head and accumulator-style tail recursion |
| 18–19 | Slide19_BacktrackingChoices.java | Recursive search and backtracking |

~~~sh
javac *.java
java Slide04_RecursiveSumProof
java Slide08_FibonacciCallTree
java Slide12_MemoizedFibonacci
java Slide15_CompareFibonacciCalls
java Slide17_HeadAndTailSum
java Slide19_BacktrackingChoices
~~~

The programs print calls, returns, cache hits, or explored choices so their runtime behavior can be compared directly with the slides.

Step-by-step recursion-analysis animations: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/

- Slides 4, 5, 7: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#recursive-sum
- Slides 8, 9, 10: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#naive-fibonacci
- Slides 11, 12, 13: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#memoized-fibonacci
- Slides 15: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#compare-calls
- Slides 16, 17: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#head-tail-sum
- Slides 18, 19: https://aisec-lab.github.io/java-examples/lecture-25-recursion-analysis/#backtracking

The comparison animation uses n=5 to show every call. Slide15_CompareFibonacciCalls.java keeps n=30. All other animation sources match the corresponding lecture Java files.
