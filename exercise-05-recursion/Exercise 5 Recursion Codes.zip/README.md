# Exercise 5: Recursion

Four short traces adapted from Lecture 23's puzzle/factorial and Lecture 24's array sum/string reverse. Use problems 1–2 after Lecture 23; add 3–4 after Lecture 24. No sorting or memoization prerequisite.

The earlier week-08 `exercise-05` on polymorphism remains unchanged. This separately named recursion package implements the current request without replacing the earlier exercise.

- `student-handout.pdf` / `Student-Handout.md`: student problems and boxed answer space.
- `solutions.pdf` / `Solutions.md`: instructor explanations and outputs.
- `java/`, `expected-output/`, and `Exercise 5 Recursion Codes.zip`: runnable Java 21 programs.
- `animation/index.html`: simulation with syntax coloring, expression boxes, scroll-attached arrows, call stack, pending operations, separate frame locals, shared-array reads, and exact console output.
- `Exercise 5 Recursion Simulation.html`: self-contained offline copy. Canvas may restrict JavaScript in a Page; use the browser file or a permitted external host.

Previous restores an earlier execution snapshot; it does not reverse the direction of the execution arrow. Every call entry, condition decision, recursive-argument evaluation, return, caller resumption, and local assignment is represented separately. This visualizes Java source-level execution rather than compiler internals. Calls into standard library operations such as println/substring are explained as source operations, not traced through JDK internals.

`trace-data.json` is the auditable timeline. Run `python3 verify.py` to compare all final simulated console output with Java and validate focus ranges, stack transitions, and executed source coverage.

## Published animations

- [puzzle](https://aisec-lab.github.io/java-examples/exercise-05-recursion/#puzzle)
- [factorial](https://aisec-lab.github.io/java-examples/exercise-05-recursion/#factorial)
- [array-sum](https://aisec-lab.github.io/java-examples/exercise-05-recursion/#array-sum)
- [reverse](https://aisec-lab.github.io/java-examples/exercise-05-recursion/#reverse)

Factorial now uses long results, rejects negative arguments, and continues to factorial(0), matching Lecture 23. Explicit rest/result locals expose the same recurrence one operation at a time.
