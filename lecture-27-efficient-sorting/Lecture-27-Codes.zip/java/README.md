# Lecture 27 Java examples

Compile all examples:

```text
javac *.java
```

Run them individually:

```text
java Slide09_MergeSort
java Slide16_QuickSort
java Slide19_PivotStrategies
java Slide22_CompareEfficientSorts
```

The sorting examples display completed merges or partitions so their recursive progress is visible.
