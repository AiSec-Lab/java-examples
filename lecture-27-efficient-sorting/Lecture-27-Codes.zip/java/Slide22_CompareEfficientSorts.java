import java.util.Arrays;

/** Verifies merge sort and quicksort on identical copies. */
public class Slide22_CompareEfficientSorts {
    public static void main(String[] args) {
        int[] original = {12, 4, 9, 4, 1, 18, 7};
        int[] mergeData = Arrays.copyOf(original, original.length);
        int[] quickData = Arrays.copyOf(original, original.length);

        Slide09_MergeSort.mergeSort(mergeData);
        Slide16_QuickSort.quickSort(quickData);

        System.out.println("merge result: " + Arrays.toString(mergeData));
        System.out.println("quick result: " + Arrays.toString(quickData));
        System.out.println("same result? " + Arrays.equals(mergeData, quickData));
    }
}
