/** Runs optimized bubble sort and displays the array after every pass. */
public class Slide12_BubbleSort {
    public static void bubbleSort(int[] values) {
        for (int pass = 0; pass < values.length - 1; pass++) {
            boolean swapped = false;
            for (int index = 0; index < values.length - 1 - pass; index++) {
                if (values[index] > values[index + 1]) {
                    ArrayTools.swap(values, index, index + 1);
                    swapped = true;
                }
            }
            ArrayTools.show("after pass " + (pass + 1) + ": ", values);
            if (!swapped) break;
        }
    }

    public static void main(String[] args) {
        int[] values = {5, 3, 9, 1, 4};
        ArrayTools.show("before: ", values);
        bubbleSort(values);
        System.out.println("sorted? " + ArrayTools.isSorted(values));
    }
}
