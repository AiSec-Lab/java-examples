/** Runs insertion sort and displays the array after every insertion. */
public class Slide21_InsertionSort {
    public static void insertionSort(int[] values) {
        for (int index = 1; index < values.length; index++) {
            int current = values[index];
            int position = index;
            while (position > 0 && values[position - 1] > current) {
                values[position] = values[position - 1];
                position--;
            }
            values[position] = current;
            ArrayTools.show("insert " + current + ": ", values);
        }
    }

    public static void main(String[] args) {
        int[] values = {6, 2, 4, 1, 5};
        ArrayTools.show("before: ", values);
        insertionSort(values);
        System.out.println("sorted? " + ArrayTools.isSorted(values));
    }
}
