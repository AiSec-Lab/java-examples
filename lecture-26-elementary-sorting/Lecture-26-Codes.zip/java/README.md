# Lecture 26 Java examples

Compile all examples from this directory:

```text
javac *.java
```

Run the traced sorting examples:

```text
java Slide12_BubbleSort
java Slide17_SelectionSort
java Slide21_InsertionSort
```

Run the timing comparison:

```text
java Slide25_SortTiming
```

The first three programs print the array after every pass. Timing values vary by computer and from run to run; compare their overall growth rather than treating one measurement as definitive.
