import java.util.Arrays;

/** Shared array operations for the lecture's sorting examples. */
public class ArrayTools {
    public static void swap(int[] values, int first, int second) {
        int temp = values[first];
        values[first] = values[second];
        values[second] = temp;
    }

    public static boolean isSorted(int[] values) {
        for (int index = 1; index < values.length; index++) {
            if (values[index - 1] > values[index]) return false;
        }
        return true;
    }

    public static void show(String label, int[] values) {
        System.out.println(label + Arrays.toString(values));
    }
}
