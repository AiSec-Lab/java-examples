import java.util.Arrays;
import java.util.Random;

/** Compares elementary sorts using identical copies of random input. */
public class Slide25_SortTiming {
    private static int[] randomArray(int length) {
        Random random = new Random(151);
        int[] values = new int[length];
        for (int index = 0; index < length; index++) {
            values[index] = random.nextInt(100_000);
        }
        return values;
    }

    private static void time(String name, int[] values, Runnable sorter) {
        long start = System.nanoTime();
        sorter.run();
        long elapsed = System.nanoTime() - start;
        System.out.printf("%-10s %,10d ns  sorted=%s%n",
                name, elapsed, ArrayTools.isSorted(values));
    }

    public static void main(String[] args) {
        int[] original = randomArray(5_000);
        int[] bubble = Arrays.copyOf(original, original.length);
        int[] selection = Arrays.copyOf(original, original.length);
        int[] insertion = Arrays.copyOf(original, original.length);

        time("bubble", bubble, () -> quietBubbleSort(bubble));
        time("selection", selection, () -> quietSelectionSort(selection));
        time("insertion", insertion, () -> quietInsertionSort(insertion));
    }

    private static void quietBubbleSort(int[] values) {
        for (int pass = 0; pass < values.length - 1; pass++) {
            boolean swapped = false;
            for (int i = 0; i < values.length - 1 - pass; i++) {
                if (values[i] > values[i + 1]) {
                    ArrayTools.swap(values, i, i + 1);
                    swapped = true;
                }
            }
            if (!swapped) return;
        }
    }

    private static void quietSelectionSort(int[] values) {
        for (int start = 0; start < values.length - 1; start++) {
            int min = start;
            for (int scan = start + 1; scan < values.length; scan++) {
                if (values[scan] < values[min]) min = scan;
            }
            ArrayTools.swap(values, start, min);
        }
    }

    private static void quietInsertionSort(int[] values) {
        for (int index = 1; index < values.length; index++) {
            int current = values[index];
            int position = index;
            while (position > 0 && values[position - 1] > current) {
                values[position] = values[position - 1];
                position--;
            }
            values[position] = current;
        }
    }
}
